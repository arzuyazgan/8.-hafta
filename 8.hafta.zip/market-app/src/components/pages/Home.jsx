import React, { useEffect, useState } from "react";

function Home () {
  const [last10Products, setLast10Products]= useState ([])
  useEffect (() =>{
      fetch['https://fakestoreapi.com/products?limit=10']
      .then(res =>res.json())
      .then(res =>setLast10Products(res))
    }  
    )
    return (
      <>
      
      <h1>Ana Sayfa</h1>
      <h2>Ürünler</h2>
      <div className="row row-cols-sm-5 row-cols-md-3">
        {last10Products.map(product =><productcard key={product.id} item={product}/>)}
      </div>

      
      
      </>


    )



}