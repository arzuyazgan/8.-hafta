import React from "react";

function Product () {
    return (
      <div>Product</div>


    )



}