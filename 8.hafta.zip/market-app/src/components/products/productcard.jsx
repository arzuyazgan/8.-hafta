import React from "react";
import { isHtmlElement } from "react-router-dom/dist/dom";

function productcard (item) {
    return (
      <div className="col-sm mb-3">
<div classname="card" >
  <img src="{item.image}" classname="card-img-top" alt="{item.title}"/>
  <div class="card-body">
    <h5 class="card-title">{item.title}</h5>
    <p class="card-text">{item.description.substring(0,25)}...</p>
     <p class="lead">{item.price}</p>
    <a href="#" class="btn btn-primary">Fav</a>
  </div>
</div>
</div>
    )
}


    



