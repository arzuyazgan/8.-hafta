import React from "react";

function ProductLayout () {
    return (
      <div>ProductLayout</div>


    )



}