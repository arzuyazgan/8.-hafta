import React from "react";
import { NavLink } from "react-router-dom";

function Navbar () {
    return (
     <nav class="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">HÜMA EŞARP & ŞAL EVİ</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <NavLink class="nav-link" to="/">ANA SAYFA</NavLink>
         <NavLink class="nav-link" to="/urunler">ÜRÜNLER</NavLink>
          <NavLink class="nav-link" to="/about">HAKKIMIZDA</NavLink>
           <NavLink class="nav-link" to="/contact">İLETİŞİM</NavLink>
      </ul>
    </div>
  </div>
</nav>


    )



}